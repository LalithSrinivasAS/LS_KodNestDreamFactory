public class Main{
    public static void main(String[]args){
        
        char gender = 'M';
        System.out.print("Gender" +gender);
    }
}