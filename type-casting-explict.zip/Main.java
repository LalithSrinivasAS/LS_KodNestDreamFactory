/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main
{
	public static void main(String[] args) {
		double pi = 3.14;
		int dupPi = (int)pi;
		//(int) keeping that value should be converted into int like that
		
		System.out.println("Pi  ="+pi);
		System.out.println("Duplicate Pi Value   ="+dupPi);
		
	    //Lalith Srinivas A S
	}
}
